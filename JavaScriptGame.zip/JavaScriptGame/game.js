
var gridSize; // This will be set using functions
var btn;
var numBombs;
var clicked = false;
var gameStart = false;
var bombs = [];
var square; // image for saquare
var canvas;
var context;



$(document).ready(function() {
	canvas = document.getElementById("game");
	context = canvas.getContext("2d");
	
	
	// These functions determine gameboard size and number of bombs
		$("#l1").on("click", function() {
			clicked = true;
			gridSize = 3;
			numBombs = 2;
		});
		
		$("#l2").on("click", function() {
			clicked = true;
			gridSize = 4;
			numBombs = 4;
		});
		
		$("#l3").on("click", function() {
			clicked = true;
			gridSize = 5;
			numBombs = 5;
		});
	
	
	// If the generate/start game button is selected then a game will start...must be clicked twice
	$("#generate").on("click", function() {
		if(gameStart == false) {
			makeGrid();
		}
		else {
			alert("You need to finish the game!");
		}
	});
	
});


//This function gets the image of the squares (origional mine sweeper!)
function makeGrid() {
	//gameStart = true; TODO if game is started do not let them continue w/out finishing!
	square = new Image();
	square.src = "square.svg";
	makeBombs();
	drawGrid();
}


//This function makes the bombs that we are going to use and it places their locations in 
//an array this array is bounded by the gridSize that is determeined above
function makeBombs(){
	
	// Place random integers into a 2x2 array, this will hold row and col of where the bomb will be
	for(var i = 0; i < numBombs; i++){
		var randRow = Math.floor((Math.random() * gridSize) + 1);
		var randCol = Math.floor((Math.random() * gridSize) + 1);
		bombs[i] = [randRow, randCol];	
	}
	console.log(bombs);
}


//This function draws the grid, it loops though gridsize and draws the grid. Starts at location (0,0) 

function drawGrid(){
	context.clearRect(0, 0, 500, 500);
	var size = gridSize * 10;
	document.getElementById("game").style.height = size;
	// Draw cubes
	for(var i = 0; i < gridSize; i++){
		var row = i * 30;			// These scale the locations so they match the image sizes
		for(var j = 0; j < gridSize; j++){
			var col = j * 30;		// These scale the locations so they match the image sizes
			context.drawImage(square, row, col, 30, 30);  // draw the images making them size 30x30 at each location
		}
	}
}